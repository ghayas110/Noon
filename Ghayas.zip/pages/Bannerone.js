/* eslint-disable @next/next/no-img-element */
import React from 'react'

function Bannerone() {
  return (
    <div>
        <a href="">
            <div className="sc-jrQzAO jBkMXf bannerModuleStrip featureBanner">
                <div className="lazyload-wrapper ">
                    <div className="sc-gKclnd jWqRCO">
                        <div className="sc-pVTFL ipLbIS">
                            <img src="https://k.nooncdn.com/cms/pages/20220430/235338afd2447c6445966118156fd086/en_dk-toggle.png" alt="/welcome-new-user" className="sc-egiyK cwhUbk"/>
                            </div>
                            </div>
                            </div>
                            </div>
                            </a>
                            </div>
  )
}

export default Bannerone